#!/bin/bash

sed -f p2aDollar.sed lastlog1.out > tmp.out
sed -f p2aDollar.sed lastlog2.out > tmp2.out
grep -f tmp.out tmp2.out > p2a.out

rm tmp*.out
