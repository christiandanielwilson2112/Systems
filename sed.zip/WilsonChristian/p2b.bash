#!/bin/bash

sed -f p2a.sed lastlog1.out > tmp.out
sed -f p2a.sed lastlog2.out >> tmp.out
sort tmp.out > tmp2.out
uniq -c tmp2.out > tmp3.out
sed -E -f p2b.sed tmp3.out > p2b.out

rm tmp*.out
