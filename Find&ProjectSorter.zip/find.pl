#!/usr/bin/perl
if($ARGV[0] eq "-i") {
    $regex = $ARGV[1];
    for($i = 2; $i <= $#ARGV; $i++) {
        grep(s/DataA\/?//g, $ARGV[$i]);
        push(@files, $ARGV[$i]);
    }   
        while(<@files>) {
        $file = $_;
        $flag = 0;
        $flag2 = 0;
        open(IN, "< DataA/$file") or die;
        while(<IN>) {
        if($file !~ /$regex/ || $_ !~ /$regex/) {
         $flag = 1;
        }
        if($file =~ /$regex/ || $_ =~ /$regex/) { 
         $flag = 0;
         $flag2 = 1;
         }
        }
        close(IN);
        if($flag == 1 && $flag2 == 0){
            print "$file\n";
        }
    }    
} else {
    $regex = $ARGV[0];
    for($i = 1; $i <= $#ARGV; $i++) {
        grep(s/DataA\/?//g, $ARGV[$i]);
        push(@files, $ARGV[$i]);
    }
   while(<@files>) {
       $file = $_;
       open($IN, "< DataA/$file") or die;
       if($file =~ /$regex/) {
        print "$file\n";
       }
       while(<$IN>) {
        if(/$regex/ && (-T $IN)) {
           print "$file:$_";
       }
    }
    close($IN);
   }
}
