#!/usr/bin/perl -w

if(scalar @ARGV != 1) {
    print "Usage: projectSorter.pl <Directory>\n";
    exit -1;
}
$data = $ARGV[0];

if(-e "$data/misc" && -d "$data/misc") {
    `rm -r $data/misc`;
}

@dir = `ls $data`;
chomp(@dir);
$i=0;
foreach $file(@dir) {
    if($file =~ /assignment/) {
       splice @dir,$i,2;
}
}

foreach $file(@dir) {
if($file =~ /proj/) {
    $file =~ /proj(.*)\./;
    if (-e "$data/assignment$1" && -d "$data/assignment$1") {
         `mv $data/$file $data/assignment$1`;       
    } else {
         `mkdir $data/assignment$1`;
         `mv $data/$file $data/assignment$1`;
    }
} else {
    if(-e "$data/misc" && -d "$data/misc") {
         `mv $data/$file $data/misc`;
    } else {
        `mkdir $data/misc`;
        `mv $data/$file $data/misc`;
}
}
}
