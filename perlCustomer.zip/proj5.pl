#!/usr/bin/perl -w

if ($#ARGV != 0) {
    print "Usage: ./proj5.pl <date>\n";
    exit;
}

$dir = Emails;
if (-e $dir and -d $dir) {
 `rm -r Emails/*`;       
} else {
 `mkdir Emails`;
}

open(my $in, 'p5Customer.txt') or die "Can't open\n";

while(<$in>) {
     my @arr = split ',', $_;
     $email = $arr[0];
     $name = $arr[1];
     my @arr2 = split ' ', $name;
     $lastname = $arr2[-1];
     $title = $arr[2];
     $paid = $arr[3];
     $owed = $arr[4];
     chomp($owed);
     $date= $ARGV[0];
     if($owed > $paid) {
        open(my $out, "> Emails/$email") or die "Can't open\n";
        open(my $temp, 'template.txt') or die "Can't open\n";
        while(my $line = <$temp>) {
            $line =~ s/EMAIL/$email/g;
            $line =~ s/FULLNAME/$name/g;
            $line =~ s/TITLE/$title/g;
            $line =~ s/NAME/$lastname/g;
            $line =~ s/AMOUNT/$owed/g;
            $line =~ s:DATE:$date:g;
            print $out $line;
        }
        close $out;
        close $temp;
    }
}

close $in;
