#include "cs3423p8.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

int concCmd(Cmd cmdM[], int iCmdCnt, Token tokenM[], int iTokenCnt) {

    int i, childPid, parentPid, arg, cmd, ret, STDINfd, STDOUTfd;
    pid_t pid;
    pid_t waitpid;
    char *argv[20];
    for(cmd = 0; cmd < iCmdCnt; cmd++) {
        pid = fork();
        switch(pid) { 
            case -1: 
                perror("fork error");
                ret = -1;
                exit(-1);
                break;
            case 0:
                if(cmdM[cmd].iStdoutRedirectIdx != 0) {
                    STDOUTfd = open(tokenM[cmdM[cmd].iStdoutRedirectIdx], O_WRONLY|O_CREAT|O_EXCL);
                    dup2(STDOUTfd, STDOUT_FILENO);
                }
                if(cmdM[cmd].iStdinRedirectIdx != 0) {
                    STDINfd = open(tokenM[cmdM[cmd].iStdinRedirectIdx], O_RDONLY);
                    dup2(STDINfd, STDIN_FILENO);
                }
                arg = 0;
                argv[arg] = cmdM[cmd].szCmdNm;
                arg++;
                for(i = cmdM[cmd].iBeginIdx; i <= cmdM[cmd].iEndIdx; i++) {
                argv[arg] = tokenM[i];
                arg++;
                }
                execvp(argv[0], argv);
                close(STDOUTfd);
                close(STDINfd);
                
                parentPid = getppid();
                childPid = getpid();
                fprintf(stderr, " %d %d: ", parentPid, childPid);
                for(i = 0; i < arg; i++) 
                    fprintf(stderr, " %s ", argv[i]);
                    fprintf(stderr, "\n");
                    exit(0);
                    break;
            default:
                ret = 0;
                waitpid = wait();
                break;
        }
    }
    return ret; 
}

int pipeCmd(Cmd cmdM[], int iCmdCnt, Token tokenM[], int iTokenCnt) {

    int fd[2];
    pid_t pid;
    char *argv[4];
    FILE *fp;
    char *modes;
    if(pipe(fd)) {
        perror("pipe error");
        exit(-1);
    }

     switch(pid = fork()) {
        case -1:
        perror("fork error");
        return -1;
        case 0:
        fprintf(stderr, "%d %d %d: %s %s %s\n", 2, getpid(), pid, cmdM[1].szCmdNm, tokenM[cmdM[1].iBeginIdx], tokenM[cmdM[1].iEndIdx]);
        close(fd[1]);
        modes = "O_WRONLY | O_CREAT | O_EXCL";
        fp = fdopen(fd[0], modes);
        dup2(fd[0], STDOUT_FILENO);
        close(fd[0]);
        argv[0] = cmdM[1].szCmdNm;
        argv[1] = tokenM[cmdM[1].iBeginIdx];
        argv[2] = tokenM[cmdM[1].iEndIdx];
        argv[3] = NULL;
        execvp(cmdM[1].szCmdNm, argv);
        fclose(fp);
        perror("exec error");
        exit(-1);
        default:
        fprintf(stderr, "%d %d %d: %s %s %s\n", 1, getpid(), pid, cmdM[0].szCmdNm, tokenM[cmdM[0].iBeginIdx], tokenM[cmdM[0].iEndIdx]);
        close(fd[0]);
        modes = "O_RDONLY";
        fp = fdopen(fd[1], modes);
        dup2(fd[1], STDIN_FILENO);
        close(fd[1]);
        argv[0] = cmdM[0].szCmdNm;
        argv[1] = tokenM[cmdM[0].iBeginIdx];
        argv[2] = tokenM[cmdM[0].iEndIdx];
        argv[3] = NULL;
        execvp(cmdM[0].szCmdNm, argv);
        fclose(fp);
        perror("exec error");
        exit(-1);
        }
    return 0;
}
