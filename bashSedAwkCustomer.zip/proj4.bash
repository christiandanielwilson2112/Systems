#!/bin/bash
#awk -f proj4.awk p4Customer.txt

if [ $# -ne 1 ]; then
    echo "Usage: $0 <date>"
    exit 1
fi

if [ -d Emails ]; then
    rm -f Emails/*
else
    mkdir Emails
fi

while read line; do
    email=`echo $line | awk -F "," '{print $1}'`
    fullname=`echo $line | awk -F "," '{print $2}'`
    lastname=`echo $fullname | awk '{print $2}'`
    title=`echo $line | awk -F "," '{print $3}'`
    paid=`echo $line | awk -F "," '{print $4}'`
    owed=`echo $line | awk -F "," '{print $5}'`
    date=$1
    if (( $(echo "$owed > $paid" | bc -l) )); then
        out="${email}"
        cat template.txt | sed -e "s/FULLNAME/$fullname/" -e "s/EMAIL/$email/" -e "s/TITLE/$title/" -e "s/NAME/$lastname/" -e "s/AMOUNT/$owed/" -e "s:DATE:$date:" > Emails/$out
fi
done < p4Customer.txt
