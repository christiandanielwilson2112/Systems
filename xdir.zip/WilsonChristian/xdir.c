#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>

extern void errExit(const char szFmt[], ... );

void flag0(DIR* dirp, struct dirent *dp) {
    
    while ((dp = readdir(dirp)) != NULL) {
       if(strncmp(".", dp->d_name, 1) != 0) {
       char buf[1024] = ""; 
       snprintf(buf, 15, "    %s\n", dp->d_name);
       write(STDOUT_FILENO, buf, 15);
        }
      }
    }

void flagL(char* dirName, DIR* dirp, struct dirent* dp) {
    
    struct stat buf;
    char* ptr;
    char path[500];
    
    while ((dp = readdir(dirp)) != NULL) {
        if(strncmp(".", dp->d_name, 1) != 0) {
        char buff[1024] = "";
        snprintf(path, sizeof(path), "%s/%s", dirName, dp->d_name);
        stat(path,&buf);
        if(S_ISREG(buf.st_mode)) {
            ptr = "F";
        } else if(S_ISDIR(buf.st_mode)) {
            ptr = "D";
        } else {
            ptr = "Unknown mode";
        }
        snprintf(buff, 35, "    %s %s %ld blks %ld bytes\n", dp->d_name,ptr,(long)buf.st_blocks,(long)buf.st_size);
        write(STDOUT_FILENO, buff, 35);
        }
      }
    }

void flagA(DIR* dirp, struct dirent *dp) {
    
     while ((dp = readdir(dirp)) != NULL) {
         char buf[1024] = "";
         snprintf(buf, 15, "    %s\n", dp->d_name);
         write(STDOUT_FILENO, buf, 15);
        }

    }

void flagLA(char* dirName, DIR* dirp, struct dirent* dp) {
    
    struct stat buf;
    char* ptr;
    char path[500];

    while ((dp = readdir(dirp)) != NULL) {
         char buff[1024] = "";
         snprintf(path, sizeof(path), "%s/%s", dirName, dp->d_name);
         stat(path,&buf);
         if(S_ISREG(buf.st_mode)) {
            ptr = "F";
         } else if(S_ISDIR(buf.st_mode)) {
            ptr = "D";
         } else {
            ptr = "Unknown mode";
         }
         snprintf(buff, 35, "    %s %s %ld blks %ld bytes\n", dp->d_name,ptr,(long)buf.st_blocks,(long)buf.st_size);
         write(STDOUT_FILENO, buff, 35);
        }
    }

int main(int argc, char* argv[]) { 
    char* progName = argv[0];
    char* dirName = argv[1];
    char buf[1024] = "";

    snprintf(buf, 10, "%s :\n", dirName);
    write(STDOUT_FILENO, buf, 10);
        
    DIR* dirp = opendir(dirName);
    struct dirent* dp;

    if(argv[2] && strcmp(argv[2],"-l") == 0 && argv[3] && strcmp(argv[3],"-a") == 0) {
        flagLA(dirName, dirp, dp);
    } else if(argv[2] && strcmp(argv[2],"-a") == 0 && argv[3] && strcmp(argv[3],"-l") == 0) {
        flagLA(dirName, dirp, dp);
    } else if(argv[2] && strcmp(argv[2],"-l") == 0) { 
        flagL(dirName, dirp, dp);
    } else if(argv[2] && strcmp(argv[2],"-a") == 0) {
        flagA(dirp, dp);
    } else if(argc == 2){ 
        flag0(dirp, dp);
    } else {
        errExit("Invalid switch");
    }
    closedir(dirp);
}   
