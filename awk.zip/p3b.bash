#!/bin/bash
awk -f p3b.awk reservation.txt > p3b.out
