#!/bin/bash

echo Apartment Number:
read apt

    for file in Data/*
    do
    if [ -f $file ] && grep -q $apt $file 
      then  
        read -a arr -d EOF < $file
        echo Email: ${arr[0]} 
        echo Name: ${arr[1]} ${arr[2]}
        echo Apt: ${arr[3]} 
        echo Balance: ${arr[5]} 
        echo Rent Amt: ${arr[4]} 
        echo Due Date: ${arr[6]} 
        flag=1
        break
    else
        flag=0
    fi
    done

    if [ $flag = 0 ]
        then
         echo Error: apartment number not found
    fi
