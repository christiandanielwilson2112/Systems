#!/bin/bash
echo Enter one of the following actions or press CTRL-D to exit.
echo C- create a customer file
echo P - accept a customer payment
echo F - find customer by apartment number
while read choice
    do
    echo
    if [ $choice = C ]
        then
            bash ./create.bash
        elif [ $choice = P ]
        then
            bash ./payment.bash
        elif [ $choice = F ]
        then
            bash ./find.bash
        else
            echo Error: invalid action value
    fi
    echo
    echo Enter one of the following actions or press CTRL-D to exit.
    echo C - create a customer file
    echo P - accept a customer payment
    echo F - find customer by apartment number
done
