#!/bin/bash

echo Customer email:
read email
echo Payment Amount:
read amt

if [ ! -e Data/$email ]
    then
    echo Error: customer not found
else
    read -a arr -d EOF < Data/$email
    arr[5]=$((${arr[5]}+$amt))
    echo ${arr[0]} ${arr[1]} ${arr[2]} > Data/$email
    echo ${arr[3]} ${arr[4]} ${arr[5]} ${arr[6]} >> Data/$email
fi
