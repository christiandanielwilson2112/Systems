#!/bin/bash

echo Customer Email:
read email
echo Customer Full Name:
read name
echo Apartment Number:
read apt
echo Monthly Rent Amt:
read amt
echo Next Due Date:
read date

flag=0
while [ $flag = 0 ]
    do
if [[ $date =~ [0-9]{4}-[0-9]{2}-[0-9]{2} ]]; then
    date=$date
    flag=1
else 
    echo Next Due Date:
    read date
fi
    done

acct=0
if [ -e Data/$email ]; then
    echo Error: customer already exists
else
    echo $email $name > Data/$email
    echo $apt $amt $acct $date >> Data/$email
fi
